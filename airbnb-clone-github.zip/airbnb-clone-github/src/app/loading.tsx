import Loader from "@/components/common/Loader";
import React from "react";

type Props = {};

const loading = (props: Props) => {
	return <Loader />;
};

export default loading;
